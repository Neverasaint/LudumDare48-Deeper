using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnvironmentText : MonoBehaviour
{
    [TextArea]
    public string text;
    public bool stepped = false;
}
